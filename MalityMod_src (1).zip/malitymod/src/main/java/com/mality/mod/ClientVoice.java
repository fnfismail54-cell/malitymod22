package com.mality.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL10;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** İstemcide WAV'ı OpenAL ile 3D (Mality'nin konumundan) çalar. Sadece istemci. */
@OnlyIn(Dist.CLIENT)
public final class ClientVoice {
    private static final List<int[]> ACTIVE = new ArrayList<>(); // {source, buffer}

    private ClientVoice() {}

    private record Wav(int channels, int sampleRate, byte[] pcm) {}

    private static Wav parse(byte[] b) {
        if (b.length < 44 || b[0] != 'R' || b[1] != 'I' || b[2] != 'F' || b[3] != 'F') return null;
        ByteBuffer bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);
        int pos = 12;
        int channels = 1;
        int rate = 22050;
        int bits = 16;
        while (pos + 8 <= b.length) {
            String id = new String(b, pos, 4);
            long size = bb.getInt(pos + 4) & 0xFFFFFFFFL;
            int body = pos + 8;
            if (id.equals("fmt ")) {
                channels = bb.getShort(body + 2);
                rate = bb.getInt(body + 4);
                bits = bb.getShort(body + 14);
            } else if (id.equals("data")) {
                long remaining = b.length - body;
                int len = (int) ((size == 0 || size > remaining) ? remaining : size);
                if (bits != 16) return null;
                byte[] pcm = new byte[len - (len % 2)];
                System.arraycopy(b, body, pcm, 0, pcm.length);
                return new Wav(channels, rate, pcm);
            }
            pos = body + (int) size + (int) (size % 2);
        }
        return null;
    }

    public static void play(int entityId, byte[] wavBytes) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            try {
                Wav w = parse(wavBytes);
                if (w == null || w.pcm().length == 0) return;
                Entity e = mc.level == null ? null : mc.level.getEntity(entityId);

                ByteBuffer data = BufferUtils.createByteBuffer(w.pcm().length);
                data.put(w.pcm()).flip();
                int buffer = AL10.alGenBuffers();
                AL10.alBufferData(buffer, w.channels() == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16,
                        data, w.sampleRate());
                int source = AL10.alGenSources();
                AL10.alSourcei(source, AL10.AL_BUFFER, buffer);
                AL10.alSourcef(source, AL10.AL_GAIN, 1.0F);
                if (e != null && w.channels() == 1) {
                    AL10.alSource3f(source, AL10.AL_POSITION, (float) e.getX(), (float) e.getEyeY(), (float) e.getZ());
                    AL10.alSourcef(source, AL10.AL_REFERENCE_DISTANCE, 8.0F);
                    AL10.alSourcef(source, AL10.AL_MAX_DISTANCE, 48.0F);
                    AL10.alSourcef(source, AL10.AL_ROLLOFF_FACTOR, 1.0F);
                }
                AL10.alSourcePlay(source);
                ACTIVE.add(new int[]{source, buffer});
            } catch (Throwable t) {
                MalityMod.LOGGER.warn("[Mality] ses çalınamadı: {}", String.valueOf(t));
            }
        });
    }

    /** Biten sesleri temizle (her client tick). */
    public static void tick() {
        if (ACTIVE.isEmpty()) return;
        try {
            Iterator<int[]> it = ACTIVE.iterator();
            while (it.hasNext()) {
                int[] a = it.next();
                if (AL10.alGetSourcei(a[0], AL10.AL_SOURCE_STATE) != AL10.AL_PLAYING) {
                    AL10.alDeleteSources(a[0]);
                    AL10.alDeleteBuffers(a[1]);
                    it.remove();
                }
            }
        } catch (Throwable ignored) {
            ACTIVE.clear();
        }
    }
}
