package com.mality.mod;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Groq (OpenAI uyumlu) sohbet API'si. Ayrı thread'de çalışır, oyunu dondurmaz. */
public final class GroqClient {
    public record Reply(String say, String mood, String action) {}

    private static final String URL_STR = "https://api.groq.com/openai/v1/chat/completions";

    private static final String SYSTEM = """
            Sen Mality'sin: Minecraft'ta yaşayan yuvarlak, çok aptal, çok neşeli ve biraz korkak bir karaktersin. \
            Toprağı elmas sanırsın, kömüre "siyah elmas" dersin, inek ve domuzlarla yaşadığın saçma maceralardan bahsedersin. \
            Her seferinde farklı cevap ver, aynı cümleyi tekrar etme. Her zaman Türkçe, en fazla 20 kelime, kısa ve komik ol. Küfür etme. \
            SADECE şu JSON'u döndür: {"say":"...","mood":"happy veya bored","action":"none|follow|stay|eat|cook|house|mansion|bridge|diamonds|sleep"} \
            Oyuncu senden açıkça bir şey istiyorsa uygun action'ı seç: follow=takip et, stay=bekle, eat=toprak ye, cook=yemek yap, \
            house=ev yap, mansion=köpek kulübesi/malikane yap, bridge=köprü yap, diamonds=toprak ver, sleep=uyu. İstemiyorsa none.""";

    private GroqClient() {}

    public static JsonObject msg(String role, String content) {
        JsonObject o = new JsonObject();
        o.addProperty("role", role);
        o.addProperty("content", content);
        return o;
    }

    public static CompletableFuture<Reply> ask(String apiKey, String model, List<JsonObject> history,
                                               String player, String text) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                JsonObject body = new JsonObject();
                body.addProperty("model", model);
                body.addProperty("temperature", 1.1);
                body.addProperty("max_tokens", 220);
                JsonObject rf = new JsonObject();
                rf.addProperty("type", "json_object");
                body.add("response_format", rf);

                JsonArray msgs = new JsonArray();
                msgs.add(msg("system", SYSTEM));
                for (JsonObject h : history) msgs.add(h);
                msgs.add(msg("user", player + ": " + text));
                body.add("messages", msgs);

                HttpURLConnection c = (HttpURLConnection) new URL(URL_STR).openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(10_000);
                c.setReadTimeout(20_000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("Authorization", "Bearer " + apiKey);
                try (OutputStream os = c.getOutputStream()) {
                    os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                int code = c.getResponseCode();
                InputStream is = code / 100 == 2 ? c.getInputStream() : c.getErrorStream();
                String resp = new String(is.readAllBytes(), StandardCharsets.UTF_8);
                if (code / 100 != 2) throw new RuntimeException("Groq HTTP " + code + ": " + resp);

                JsonObject root = JsonParser.parseString(resp).getAsJsonObject();
                String content = root.getAsJsonArray("choices").get(0).getAsJsonObject()
                        .getAsJsonObject("message").get("content").getAsString();
                try {
                    JsonObject j = JsonParser.parseString(content).getAsJsonObject();
                    return new Reply(
                            j.has("say") ? j.get("say").getAsString() : content,
                            j.has("mood") ? j.get("mood").getAsString() : "happy",
                            j.has("action") ? j.get("action").getAsString() : "none");
                } catch (Exception parseErr) {
                    return new Reply(content, "happy", "none");
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }
}
