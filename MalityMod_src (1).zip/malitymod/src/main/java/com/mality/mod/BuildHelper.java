package com.mality.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/** Mality'nin yaptığı evler. İçeri girilebilen alanı (AABB) döndürür. */
public final class BuildHelper {
    private BuildHelper() {}

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState DIRT = Blocks.DIRT.defaultBlockState();
    private static final BlockState COARSE = Blocks.COARSE_DIRT.defaultBlockState();

    private static void set(ServerLevel l, int x, int y, int z, BlockState s) {
        l.setBlock(new BlockPos(x, y, z), s, 3);
    }

    private static void clear(ServerLevel l, int x0, int y0, int z0, int x1, int y1, int z1) {
        for (int x = x0; x <= x1; x++)
            for (int y = y0; y <= y1; y++)
                for (int z = z0; z <= z1; z++)
                    set(l, x, y, z, AIR);
    }

    private static void foundation(ServerLevel l, int x0, int x1, int z0, int z1, int y) {
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                for (int yy = y - 1; yy >= y - 4; yy--) {
                    BlockPos p = new BlockPos(x, yy, z);
                    if (l.isEmptyBlock(p) || l.getBlockState(p).canBeReplaced()) set(l, x, yy, z, DIRT);
                    else break;
                }
            }
        }
    }

    // ------------------------------------------------------------ KÖTÜ (eğri, delikli) ev
    public static AABB buildUglyHouse(ServerLevel l, BlockPos c, Direction dir) {
        RandomSource r = l.random;
        int y = c.getY();
        int w = r.nextInt(3) + 4, d = r.nextInt(3) + 4;
        int x0 = c.getX() - w / 2, z0 = c.getZ() - d / 2, x1 = x0 + w - 1, z1 = z0 + d - 1;
        clear(l, x0 - 1, y, z0 - 1, x1 + 2, y + 6, z1 + 2);
        foundation(l, x0, x1 + 1, z0, z1, y);
        BlockState[] mats = {DIRT, Blocks.GRAVEL.defaultBlockState(), COARSE, Blocks.SAND.defaultBlockState(),
                Blocks.PODZOL.defaultBlockState()};
        for (int h = 0; h <= 3; h++) {
            int sh = h >= 2 ? 1 : 0;          // üst katlar kayık = eğri bina
            for (int x = x0 + sh; x <= x1 + sh; x++) {
                for (int z = z0; z <= z1; z++) {
                    boolean wall = x == x0 + sh || x == x1 + sh || z == z0 || z == z1;
                    if (h == 3) {
                        if (r.nextInt(100) < 55) set(l, x, y + h, z, mats[r.nextInt(mats.length)]);
                    } else if (wall && r.nextInt(100) < 75) {
                        set(l, x, y + h, z, mats[r.nextInt(mats.length)]);
                    }
                }
            }
        }
        int dx = c.getX() - dir.getStepX() * (w / 2), dz = c.getZ() - dir.getStepZ() * (d / 2);
        set(l, dx, y, dz, AIR);
        set(l, dx, y + 1, dz, AIR);
        return new AABB(x0 + 1, y, z0 + 1, x1, y + 3, z1);
    }

    // ------------------------------------------------------------ GÜZEL kulübe (kötü istenince)
    public static AABB buildNiceHouse(ServerLevel l, BlockPos c, Direction dir) {
        int y = c.getY();
        int x0 = c.getX() - 3, x1 = c.getX() + 3, z0 = c.getZ() - 3, z1 = c.getZ() + 3;
        clear(l, x0 - 2, y, z0 - 2, x1 + 2, y + 10, z1 + 2);
        foundation(l, x0, x1, z0, z1, y);
        BlockState planks = Blocks.OAK_PLANKS.defaultBlockState();
        BlockState log = Blocks.OAK_LOG.defaultBlockState();
        BlockState bricks = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState glass = Blocks.GLASS_PANE.defaultBlockState();
        int doorX = c.getX() - dir.getStepX() * 3, doorZ = c.getZ() - dir.getStepZ() * 3;
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                boolean edge = x == x0 || x == x1 || z == z0 || z == z1;
                boolean corner = (x == x0 || x == x1) && (z == z0 || z == z1);
                set(l, x, y - 1, z, edge ? bricks : planks);
                for (int h = 0; h <= 3; h++) {
                    if (!edge) { set(l, x, y + h, z, AIR); continue; }
                    if (x == doorX && z == doorZ && h <= 1) { set(l, x, y + h, z, AIR); continue; }
                    if (corner) set(l, x, y + h, z, log);
                    else if (h == 0) set(l, x, y + h, z, bricks);
                    else if ((h == 1 || h == 2) && (x + z) % 2 == 0) set(l, x, y + h, z, glass);
                    else set(l, x, y + h, z, planks);
                }
            }
        }
        // piramit çatı
        BlockState roof = Blocks.SPRUCE_PLANKS.defaultBlockState();
        for (int k = 0; k <= 4; k++) {
            int half = 4 - k;
            for (int x = c.getX() - half; x <= c.getX() + half; x++)
                for (int z = c.getZ() - half; z <= c.getZ() + half; z++)
                    set(l, x, y + 4 + k, z, roof);
        }
        set(l, c.getX(), y + 3, c.getZ(), Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true));
        set(l, x1 - 1, y, z1 - 1, Blocks.CRAFTING_TABLE.defaultBlockState());
        set(l, x0 + 1, y, z1 - 1, Blocks.TORCH.defaultBlockState());
        return new AABB(x0 + 1, y, z0 + 1, x1, y + 4, z1);
    }

    // ------------------------------------------------------------ köprü (yukarı = mal köprü)
    public static void buildBridge(ServerLevel l, BlockPos start, Direction dir, boolean up) {
        Direction side = dir.getClockWise();
        BlockState plank = Blocks.OAK_PLANKS.defaultBlockState();
        BlockState fence = Blocks.OAK_FENCE.defaultBlockState();
        int len = 20;
        int maxY = l.getMaxBuildHeight() - 6;
        for (int i = 1; i <= len; i++) {
            int dy = up ? i : 0;
            if (start.getY() - 1 + dy > maxY) break;
            BlockPos center = start.relative(dir, i).above(dy - 1);
            for (int s = -1; s <= 1; s++) {
                BlockPos p = center.relative(side, s);
                l.setBlock(p, plank, 3);
                for (int h = 1; h <= 3; h++) l.setBlock(p.above(h), AIR, 3);
                if (s != 0) l.setBlock(p.above(1), fence, 3);
            }
        }
    }

    // ------------------------------------------------------------ malikane (17x13, 2 kat)
    public static AABB buildMansion(ServerLevel l, BlockPos c, Direction dir) {
        int y = c.getY();
        int hx = 8, hz = 6;
        int x0 = c.getX() - hx, x1 = c.getX() + hx, z0 = c.getZ() - hz, z1 = c.getZ() + hz;
        clear(l, x0 - 1, y, z0 - 1, x1 + 1, y + 12, z1 + 1);
        foundation(l, x0, x1, z0, z1, y);

        // kapı koordinatları (arka duvarın ortası, 3 geniş)
        int backX = c.getX() - dir.getStepX() * hx;
        int backZ = c.getZ() - dir.getStepZ() * hz;
        boolean xAxis = dir.getStepX() != 0;

        BlockState planks = Blocks.OAK_PLANKS.defaultBlockState();
        BlockState log = Blocks.OAK_LOG.defaultBlockState();
        BlockState glass = Blocks.GLASS_PANE.defaultBlockState();

        int ladderX = x0 + 1;
        int ladderZ = z0 + 2;

        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                boolean edge = x == x0 || x == x1 || z == z0 || z == z1;
                boolean corner = (x == x0 || x == x1) && (z == z0 || z == z1);

                set(l, x, y - 1, z, edge ? DIRT : planks); // zemin
                for (int h = 0; h <= 8; h++) {
                    int yy = y + h;
                    if (h == 4) { // 2. kat zemini
                        if (edge) set(l, x, yy, z, DIRT);
                        else if (x == ladderX && z == ladderZ) set(l, x, yy, z, AIR);
                        else set(l, x, yy, z, planks);
                    } else if (edge) {
                        boolean door = xAxis
                                ? (x == backX && Math.abs(z - c.getZ()) <= 1 && h <= 2)
                                : (z == backZ && Math.abs(x - c.getX()) <= 1 && h <= 2);
                        if (door) {
                            set(l, x, yy, z, AIR);
                        } else if (corner) {
                            set(l, x, yy, z, log);
                        } else if ((h == 1 || h == 2 || h == 5 || h == 6) && ((x + z) % 3 == 0)) {
                            set(l, x, yy, z, glass);
                        } else {
                            set(l, x, yy, z, ((x + z + h) % 5 == 0) ? COARSE : DIRT);
                        }
                    } else {
                        if (!(h == 4)) set(l, x, yy, z, AIR);
                    }
                }
                set(l, x, y + 9, z, DIRT);                       // çatı
                if (edge) set(l, x, y + 10, z, COARSE);          // siperlik
            }
        }

        // merdiven (2. kata)
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.EAST);
        for (int h = 0; h <= 4; h++) set(l, ladderX, y + h, ladderZ, ladder);

        // meşaleler (alt ve üst kat)
        set(l, x1 - 1, y, z1 - 1, Blocks.TORCH.defaultBlockState());
        set(l, x1 - 1, y, z0 + 1, Blocks.TORCH.defaultBlockState());
        set(l, x0 + 2, y, z1 - 1, Blocks.TORCH.defaultBlockState());
        set(l, x1 - 1, y + 5, z1 - 1, Blocks.TORCH.defaultBlockState());
        set(l, x1 - 1, y + 5, z0 + 1, Blocks.TORCH.defaultBlockState());
        set(l, x0 + 2, y + 5, z1 - 1, Blocks.TORCH.defaultBlockState());

        return new AABB(x0 + 1, y, z0 + 1, x1, y + 4, z1);
    }
}
