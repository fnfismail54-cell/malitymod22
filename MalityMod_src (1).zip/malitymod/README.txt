MALITY MOD  -  Minecraft Java 1.20.1  -  Forge 47.x  -  Java 17
==============================================================

KURULUM / DERLEME (en kolay yol)
1) https://files.minecraftforge.net adresinden 1.20.1 icin "MDK" indir (47.3.0 veya yakini) ve ac.
2) Bu zip'teki "src" klasorunu MDK'nin icindeki "src" klasorunun ustune kopyala (mevcut Example mod
   dosyalarini sil: src/main/java/com/example..., eski mods.toml).
3) MDK'deki build.gradle ve gradle.properties icindeki mod id'yi "malitymod", paket/group'u
   "com.mality.mod" yap. (Alternatif: bu zip'teki build.gradle'i ve settings.gradle'i kullan,
   gradle wrapper'i MDK'den kopyala: gradlew, gradlew.bat, gradle/ klasoru.)
4) JDK 17 kurulu olsun. Terminalde:   gradlew build
5) Jar:  build/libs/malitymod-1.0.0.jar  ->  .minecraft/mods klasorune at.
   (Forge 1.20.1 kurulu olmali.)

OYUN ICI (v2)
- Yaratici envanteri > "Mality" sekmesi: Malitynin Mavi Kutusu, Mality Canlandirma Yumurtasi,
  Malitynin Super Keki.
- Mavi kutuyu yere koy, SAG TIK: havaya kalkar, ses cikar, Mality duser ("tip"), sacma seyler soyler.
- Ayarlar: Mods > Mality > Config: Groq API key + model, Fish Audio API key + Fish Audio ses model ID
  (Fish Audio sitesindeki voice model ID), "mality de" kutusu.
  Fish Audio key bos ise Mality sessiz konusur (sadece yazi). Anahtarlar config/malitymod-common.toml
  icinde duz yazi saklanir, paylasma!
- Komutlar: "yemek yap" (asci sapkasi, tezgah, malzemeler, super kek), "yemek ye", "toprak ver",
  "yardim et", "ev yap" (kotu ev; "kotu ev yap" derseniz guzel yapar), "kopek kulubesi yap" (malikane),
  "kopru yap" (yukari; "kotu kopru" duz yapar), "uyu", "takip et", "dur/bekle".
- Sohbete /setmalityyatak yaz: en yakin Mality'nin yatagi bulundugun yer olur. "uyu" deyince ya da
  gece olunca yuvarlanarak oraya gider ve uyur.
- Super kek: bulanti + rastgele ucak / tavsan (yuksek ziplama) / osuruk. Zehirliyse kisa zehir (olmez).

YUZLER (BIR FOTO)
assets/malitymod/textures/entity/mality_faces.png  (256x128, 4x2 hucre, her hucre 64x64):
  ust sira:  mutlu | mutlu konusurken | sikilmis/korkunc | sikilmis konusurken
  alt sira:  uyuyan | korkmus | dusen | (sag alt hucre = top rengi, boyle birak)
Her yuz hucrenin icinde YUVARLAK cizilmeli, hucrenin kenari top rengi (sari) olsun.

BILGISAYARSIZ DERLEME (GitHub ile)
Depoya (repo) tum dosyalari, .github/workflows/build.yml dahil, yukle. Actions sekmesi >
"Build Mality Mod" > Run workflow. Bitince "malitymod-jar" artifact'ini indir, icinden jar cikar.
