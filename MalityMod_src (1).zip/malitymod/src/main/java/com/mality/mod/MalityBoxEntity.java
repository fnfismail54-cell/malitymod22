package com.mality.mod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

/** Mavi Mality kutusu: sağ tıkla -> havaya kalkar, ses çıkar, içinden Mality düşer. */
public class MalityBoxEntity extends Entity {
    private static final EntityDataAccessor<Integer> OPEN =
            SynchedEntityData.defineId(MalityBoxEntity.class, EntityDataSerializers.INT);

    public MalityBoxEntity(EntityType<? extends MalityBoxEntity> type, Level level) {
        super(type, level);
        this.noPhysics = false;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(OPEN, -1);
    }

    public int openTicks() {
        return this.entityData.get(OPEN);
    }

    @Override
    public boolean isPickable() {
        return true;
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (this.level().isClientSide) return InteractionResult.SUCCESS;
        if (openTicks() < 0) {
            this.entityData.set(OPEN, 0);
            this.level().playSound(null, this.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.NEUTRAL, 1.5F, 1.4F);
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public void tick() {
        super.tick();
        int o = openTicks();
        if (o < 0) return;
        if (this.level().isClientSide) {
            if (o % 2 == 0) {
                this.level().addParticle(ParticleTypes.END_ROD, this.getX() + (random.nextDouble() - 0.5) * 0.8,
                        this.getY() + 0.1, this.getZ() + (random.nextDouble() - 0.5) * 0.8, 0, -0.02, 0);
            }
            return;
        }
        o++;
        this.entityData.set(OPEN, o);
        if (o <= 30) this.setPos(this.getX(), this.getY() + 0.1D, this.getZ()); // havaya kalkar
        if (o == 45 && this.level() instanceof ServerLevel sl) {
            MalityEntity m = MalityMod.MALITY.get().create(sl);
            if (m != null) {
                m.moveTo(this.getX(), this.getY() + 0.4D, this.getZ(), this.getYRot(), 0.0F);
                m.setFalling(true);
                sl.addFreshEntity(m);
            }
            sl.playSound(null, this.blockPosition(), SoundEvents.CHEST_OPEN, SoundSource.NEUTRAL, 1.5F, 0.8F);
            sl.sendParticles(ParticleTypes.POOF, this.getX(), this.getY() + 0.5, this.getZ(), 20, 0.3, 0.3, 0.3, 0.05);
            this.discard();
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
