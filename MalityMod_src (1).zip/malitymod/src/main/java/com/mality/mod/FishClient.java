package com.mality.mod;

import com.google.gson.JsonObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

/** Fish Audio TTS: metni WAV sese çevirir (POST /v1/tts). */
public final class FishClient {
    private FishClient() {}

    public static CompletableFuture<byte[]> tts(String apiKey, String voiceId, String engine, String text) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                JsonObject body = new JsonObject();
                body.addProperty("text", text);
                if (voiceId != null && !voiceId.isBlank()) body.addProperty("reference_id", voiceId.trim());
                body.addProperty("format", "wav");
                body.addProperty("sample_rate", 22050);
                body.addProperty("normalize", true);

                HttpURLConnection c = (HttpURLConnection) new URL("https://api.fish.audio/v1/tts").openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(10_000);
                c.setReadTimeout(30_000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("Authorization", "Bearer " + apiKey);
                c.setRequestProperty("model", engine == null || engine.isBlank() ? "s1" : engine.trim());
                try (OutputStream os = c.getOutputStream()) {
                    os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                int code = c.getResponseCode();
                InputStream is = code / 100 == 2 ? c.getInputStream() : c.getErrorStream();
                byte[] data = is.readAllBytes();
                if (code / 100 != 2) {
                    throw new RuntimeException("Fish Audio HTTP " + code + ": " + new String(data, StandardCharsets.UTF_8));
                }
                return data;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }
}
